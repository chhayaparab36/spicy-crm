class UnableToGetReadingsConfig(Exception):
    pass


class UnableToIngestReadingsFile(Exception):
    pass
